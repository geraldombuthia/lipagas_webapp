export { default } from './Image';
